package com.uts.first_flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
