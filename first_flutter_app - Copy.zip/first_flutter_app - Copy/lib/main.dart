import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

void main() {
  runApp(const StudentInfoApp());
}

class StudentInfoApp extends StatelessWidget {
  const StudentInfoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CSS3344 Lab 02',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
      ),
      home: const StudentProfileScreen(),
    );
  }
}

class StudentProfileScreen extends StatefulWidget {
  const StudentProfileScreen({super.key});

  @override
  State<StudentProfileScreen> createState() => _StudentProfileScreenState();
}

class _StudentProfileScreenState extends State<StudentProfileScreen> {
  DateTime _selectedDate = DateTime.now();

  // Role list from your lab snippet (swap with ['Gryffindor', 'Slytherin', 'Ravenclaw', 'Hufflepuff'] if needed)
  final List<String> _roles = ['Student', 'Developer', 'Designer'];
  String _selectedRole = 'Student';

  String get _formattedDate => _selectedDate.toLocal().toString().split(' ')[0];

  // 1. Material Date Picker
  Future<void> _selectMaterialDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(1950),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  // 2. Cupertino Date Picker with "Done" bar
  void _showCupertinoDatePicker(BuildContext context) {
    showCupertinoModalPopup(
      context: context,
      builder: (_) => Container(
        height: 260,
        color: CupertinoColors.systemBackground.resolveFrom(context),
        child: Column(
          children: [
            Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: CupertinoButton(
                padding: EdgeInsets.zero,
                child: const Text('Done'),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
            Expanded(
              child: CupertinoDatePicker(
                mode: CupertinoDatePickerMode.date,
                initialDateTime: _selectedDate,
                onDateTimeChanged: (DateTime newDate) {
                  setState(() => _selectedDate = newDate);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 3. Cupertino Role Wheel Picker with "Done" bar
  void _showCupertinoRolePicker(BuildContext context) {
    showCupertinoModalPopup(
      context: context,
      builder: (_) => Container(
        height: 240,
        color: CupertinoColors.systemBackground.resolveFrom(context),
        child: Column(
          children: [
            Container(
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: CupertinoButton(
                padding: EdgeInsets.zero,
                child: const Text('Done'),
                onPressed: () => Navigator.of(context).pop(),
              ),
            ),
            Expanded(
              child: CupertinoPicker(
                itemExtent: 32,
                scrollController: FixedExtentScrollController(
                  initialItem: _roles.indexOf(_selectedRole),
                ),
                onSelectedItemChanged: (int index) {
                  setState(() => _selectedRole = _roles[index]);
                },
                children: _roles.map((role) => Center(child: Text(role))).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Interactive Pickers Section (Lab 2.2)
  Widget _buildInteractivePickersSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(height: 32, thickness: 1),
        const Text(
          'Interactive Pickers (Lab 2.2)',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'Selected Date: $_formattedDate',
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: Colors.black87,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Selected Role: $_selectedRole',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: Colors.indigo[600],
          ),
        ),
        const SizedBox(height: 14),
        ElevatedButton.icon(
          onPressed: () => _selectMaterialDate(context),
          icon: const Icon(Icons.calendar_month, size: 18),
          label: const Text('Material Date Picker'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => _showCupertinoDatePicker(context),
          icon: const Icon(Icons.date_range, size: 18),
          label: const Text('Cupertino Date Picker (iOS)'),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            const Text(
              'Material Dropdown:',
              style: TextStyle(
                fontSize: 14,
                color: Colors.black87,
              ),
            ),
            const SizedBox(width: 12),
            DropdownButton<String>(
              value: _selectedRole,
              items: _roles.map((String role) {
                return DropdownMenuItem<String>(
                  value: role,
                  child: Text(role),
                );
              }).toList(),
              onChanged: (String? newValue) {
                if (newValue != null) {
                  setState(() => _selectedRole = newValue);
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => _showCupertinoRolePicker(context),
          icon: const Icon(Icons.unfold_more, size: 18),
          label: const Text('Cupertino Role Wheel Picker'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CSS3344 Mobile App Dev - Lab 02'),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      ),
      body: OrientationBuilder(
        builder: (context, orientation) {
          return orientation == Orientation.portrait
              ? _buildPortraitView(context)
              : _buildLandscapeView(context);
        },
      ),
    );
  }

  // Portrait Mode
  Widget _buildPortraitView(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Card(
        elevation: 4,
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const ProfileCard(),
              const SizedBox(height: 16),
              const TitleSection(
                name: 'Bandar Sibu, Sarawak',
                location: 'Sibu, Sarawak, Malaysia',
                starCount: 41,
              ),
              const SizedBox(height: 16),
              const ImageSection(
                imagePath: 'assets/icon/sibu.png',
                height: 200,
              ),
              _buildInteractivePickersSection(context),
            ],
          ),
        ),
      ),
    );
  }

  // Landscape Mode
  Widget _buildLandscapeView(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Card(
        elevation: 4,
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Expanded(
                flex: 1,
                child: ProfileCard(),
              ),
              const SizedBox(width: 20),
              Expanded(
                flex: 1,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const TitleSection(
                      name: 'University Technology Sarawak',
                      location: 'Sibu, Sarawak, Malaysia',
                      starCount: 41,
                    ),
                    const SizedBox(height: 12),
                    const ImageSection(
                      imagePath: 'assets/icon/sibu.png',
                      height: 180,
                    ),
                    _buildInteractivePickersSection(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- 1. Indigo Profile Card Widget ---
class ProfileCard extends StatelessWidget {
  const ProfileCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        color: Colors.indigo[600],
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CircleAvatar(
            radius: 50,
            backgroundColor: Colors.white24,
            backgroundImage: AssetImage('assets/icon/icon.jpeg'),
          ),
          SizedBox(height: 14),
          Text(
            'JOSHUA GRUNER ANAK CHANGGAN',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Student ID: BCS25020008',
            style: TextStyle(
              fontSize: 13,
              color: Colors.white70,
            ),
          ),
          Divider(
            height: 24,
            thickness: 1,
            color: Colors.white38,
          ),
          Text(
            'Personal Life Goal / Quote:',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 6),
          Text(
            '"My dream is to finish my degree and have a stable job"',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontStyle: FontStyle.italic,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}

// --- 2. Title & Star Rating Section ---
class TitleSection extends StatelessWidget {
  final String name;
  final String location;
  final int starCount;

  const TitleSection({
    super.key,
    required this.name,
    required this.location,
    required this.starCount,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4.0, vertical: 4.0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  location,
                  style: TextStyle(
                    color: Colors.indigo[400],
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          Icon(Icons.star, color: Colors.indigo[400], size: 20),
          const SizedBox(width: 4),
          Text(
            '$starCount',
            style: const TextStyle(
              fontSize: 13,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}

// --- 3. Rounded Image Section ---
class ImageSection extends StatelessWidget {
  final String imagePath;
  final double height;

  const ImageSection({
    super.key,
    required this.imagePath,
    this.height = 200,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: Image.asset(
        imagePath,
        width: double.infinity,
        height: height,
        fit: BoxFit.cover,
        errorBuilder: (context, error, stackTrace) {
          return Container(
            width: double.infinity,
            height: height,
            color: Colors.indigo[50],
            child: const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.landscape, size: 48, color: Colors.indigo),
                SizedBox(height: 8),
                Text(
                  'Check image path in pubspec.yaml',
                  style: TextStyle(fontSize: 12, color: Colors.indigo),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}